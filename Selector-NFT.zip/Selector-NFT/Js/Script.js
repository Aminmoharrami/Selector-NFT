let Select = document.getElementById('myDiv');
Select.addEventListener("toggle", myFunction);

let Select1 = document.getElementById('myDiv1');
Select1.addEventListener("toggle", myFunction1);

function myFunction() {
    if (Select) {
        Select.style.borderBottomColor = "thick solid #ffffff00"
    } else {
        Select.style.borderBottomColor = "rgba(255, 199, 0, 1)"
    }
}

function myFunction1() {
    if (Select1) {
        Select1.style.borderBottomColor = "thick solid #ffffff00"
    } else {
        Select1.style.borderBottomColor = "rgba(255, 199, 0, 1)"
    }
}

function myFunction2() {
    if (Select1) {
        Select1.style.borderBottomColor = "thick solid #ffffff00"
    } else {
        Select1.style.borderBottomColor = "rgba(255, 199, 0, 1)"
    }
}

function myFunction3() {
    if (Select1) {
        Select1.style.borderBottomColor = "thick solid #ffffff00"
    } else {
        Select1.style.borderBottomColor = "rgba(255, 199, 0, 1)"
    }
}

function myFunction4() {
    if (Select1) {
        Select1.style.borderBottomColor = "thick solid #ffffff00"
    } else {
        Select1.style.borderBottomColor = "rgba(255, 199, 0, 1)"
    }
}




let Query = document.getElementById('pic_2');
let Query1 = document.getElementById('pic_3');
let Query2 = document.getElementById('pic_4');
let Query3 = document.getElementById('pic_5');
let Query4 = document.getElementById('pic_6');
let fuery = document.getElementById('zoomed-image');

Query.addEventListener('toggle', Quey())
Query1.addEventListener('toggle', Quey1())
Query1.addEventListener('toggle', Quey2())
Query1.addEventListener('toggle', Quey3())
Query1.addEventListener('toggle', Quey4())

function Quey() {
    fuery.src = "/img/Banner1.png"
}

function Quey1() {
    fuery.src = "/img/Banner_2.png"
}

function Quey2() {
    fuery.src = "/img/Banner_3.png"
}

function Quey3() {
    fuery.src = "/img/Banner_5.png"
}

function Quey4() {
    fuery.src = "/img/Banner_4.png"
}