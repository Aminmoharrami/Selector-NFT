(function (window) {
    let defineLibrary = () => ({
        init: function (galleryId) {
            let container = document.querySelector(galleryId);
            if (!container) {
                console.error('please add the correct element')
                return;
            }
            let firstImage = container.querySelector('.small-preview')
            let zoomedImage = container.querySelector('#zoomed-image');
            zoomedImage.src = "/img/Banner1.png"           
        }
    })
    if (typeof (vanillaZoom) == 'undefined') {
        window.vanillaZoom = defineLibrary();
    } else {
        console.log('library already defined.')
    }
})(window)

